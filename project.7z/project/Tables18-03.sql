USE [Training_18Jan2017_Talwade]
GO

/****** Object:  Schema [MySchemaEMS]    Script Date: 3/18/2017 2:51:59 PM ******/
CREATE SCHEMA [MySchemaEMS]
GO

CREATE TABLE [MySchemaEMS].EmployeeDetails
(
EmpID INT PRIMARY KEY IDENTITY(121100,1),
DeptID INT FOREIGN KEY REFERENCES  [MySchemaEMS].DeptDetails(DeptID),
EmpFName VARCHAR(20) NOT NULL,
EmpLName VARCHAR(20) NOT NULL,
EmpGender CHAR NOT NULL
CONSTRAINT CHK_Gender CHECK (EmpGender='M' OR EmpGender='F'),
EmpAge INT NOT NULL
CONSTRAINT CHK_Age CHECK(EmpAge>=18 AND EmpAge<=60),
EmpDesignation VARCHAR(20) NOT NULL,
EmpSalary NUMERIC(10,2) NOT NULL,
EmpAddress VARCHAR(50) NOT NULL,
EmpDOB Date NOT NULL,
EmpDOJ Datetime NOT NULL,
EmpContactNo NUMERIC(10) NOT NULL,
EmpEmailId VARCHAR(30) NOT NULL
)

INSERT INTO [MySchemaEMS].EmployeeDetails
VALUES(112,'Shruti','Hassan','F',22,'Developer',200000,'Nagpur','03/24/2017','01/18/2017',9870657483,'shruti@gmail.com')
INSERT INTO [MySchemaEMS].EmployeeDetails
VALUES(112,'Shruti','Hassan','F',22,'Developer',200000,'Nagpur','03/24/2017','01/18/2017',9870657483,'shruti@gmail.com')
INSERT INTO [MySchemaEMS].EmployeeDetails
VALUES(112,'Shruti','Hassan','F',22,'Developer',200000,'Nagpur','04/28/2017','01/18/2017',9870657483,'shruti@gmail.com')


SELECT * FROM  [MySchemaEMS].EmployeeDetails

DROP TABLE [MySchemaEMS].EmployeeDetails

CREATE TABLE [MySchemaEMS].ClientDetails
(
ClientID INT PRIMARY KEY,
ProjectName VARCHAR(40) NOT NULL,
StartDate Date NOT NULL,
EndDate Date NOT NULL
)

DROP TABLE [MySchemaEMS].ClientDetails

CREATE TABLE [MySchemaEMS].DeptDetails(
DeptID INT PRIMARY KEY,
DeptName VARCHAR(20) NOT NULL,
DeptLocation VARCHAR(20) NOT NULL
)

INSERT INTO [MySchemaEMS].DeptDetails
VALUES(112,'HR','MUMBAI')

DROP TABLE [MySchemaEMS].DeptDetails


CREATE TABLE [MySchemaEMS].ProjectDetails(
ProjectID INT PRIMARY KEY,
ProjectName VARCHAR(40) NOT NULL,
ProjectTechnology VARCHAR(50) NOT NULL
)

DROP TABLE [MySchemaEMS].ProjectDetails

CREATE TABLE [MySchemaEMS].ProjectAllocationDetails(
ProjectID INT FOREIGN KEY REFERENCES  [MySchemaEMS].ProjectDetails(ProjectID),
ProjectName VARCHAR(40) NOT NULL,
ProjectManager VARCHAR(20) NOT NULL,
ProjectTL VARCHAR(20) NOT NULL
)      
--start date and end date will be taken from clientDetails table

DROP TABLE [MySchemaEMS].ProjectAllocationDetails

CREATE TABLE [MySchemaEMS].LoginDetails(
UserID VARCHAR(30) PRIMARY KEY,
UserPswd VARCHAR(30) NOT NULL,
UserType VARCHAR(30) NOT NULL
)

INSERT INTO [MySchemaEMS].LoginDetails
VALUES('root123','root123','HR')

INSERT INTO [MySchemaEMS].LoginDetails
VALUES('root','root123','MANAGER')

SELECT * FROM [MySchemaEMS].LoginDetails


--Stored Procedure

--Stored Procedure for Adding the Employee Record
CREATE PROCEDURE [MySchemaEMS].AddEmployeeRecord
(
	@EmpID INT OUT,
	@EmpFName VARCHAR(20),
	@EmpLName VARCHAR(20),
	@EmpGender CHAR,
	@EmpAge INT,
	@EmpDesignation VARCHAR(20),
	@EmpSalary NUMERIC(10,2),
	@EmpAddress VARCHAR(50),
	@EmpDOB Date,
	@EmpDOJ Datetime,
	@EmpContactNo NUMERIC(10),
	@EmpEmailId VARCHAR(30)	
)
AS
INSERT INTO [MySchemaEMS].EmployeeDetails
VALUES(@EmpFName,@EmpLName,@EmpGender,@EmpAge,@EmpDesignation,@EmpSalary,
@EmpAddress,@EmpDOB,@EmpDOJ,@EmpContactNo,@EmpEmailId)


--Stored Procedure for Displaying the Employee Record
CREATE PROCEDURE [MySchemaEMS].DisplayAllEmployee
AS
SELECT * FROM [MySchemaEMS].EmployeeDetails


--Stored Procedure for Searching the Employee Record
CREATE PROCEDURE [MySchemaEMS].RetrieveEmployeeDetails
(
	@EmpID INT
)
AS
SELECT * FROM [MySchemaEMS].EmployeeDetails
WHERE EmpID=@EmpID


--Stored Procedure for Deleting the Employee Record
CREATE PROCEDURE [MySchemaEMS].DeleteEmployeeDetails
(
	@EmpID INT
)
AS
DELETE FROM [MySchemaEMS].EmployeeDetails
WHERE  EmpID=@EmpID


--Stored Procedure for Updating the Employee Record
CREATE PROCEDURE [MySchemaEMS].UpdateEmployeeDetails
(
	@EmpID INT,
	@EmpFName VARCHAR(20),
	@EmpLName VARCHAR(20),
	@EmpGender CHAR,
	@EmpAge INT,
	@EmpDesignation VARCHAR(20),
	@EmpSalary NUMERIC(10,2),
	@EmpAddress VARCHAR(50),
	@EmpDOB Date,
	@EmpDOJ Datetime,
	@EmpContactNo NUMERIC(10),
	@EmpEmailId VARCHAR(30)	
)
AS
UPDATE [MySchemaEMS].EmployeeDetails 
SET EmpFName=@EmpFName,EmpLName=@EmpLName,EmpGender=@EmpGender,EmpAge=@EmpAge,
EmpDesignation=@EmpDesignation,EmpSalary=@EmpSalary,EmpAddress=@EmpAddress,EmpDOB=@EmpDOB,
EmpDOJ=@EmpDOJ,EmpContactNo=@EmpContactNo,EmpEmailId=@EmpEmailId
WHERE EmpID=@EmpID


CREATE PROCEDURE [MySchemaEMS].EmployeeBirthday
(
	@EmpID INT,
	@EmpFName VARCHAR(20),
	@EmpLName VARCHAR(20),
	@EmpDOB Date OUT
) 
AS
SELECT @EmpID,@EmpFName,@EmpLName,@EmpDOB 
FROM [MySchemaEMS].EmployeeDetails
WHERE @EmpDOB=EmpDOB



CREATE PROCEDURE [MySchemaEMS].EmployeeBirthday
(
	@EmpDOB Date OUT
) 
AS
SELECT * 
FROM [MySchemaEMS].EmployeeDetails
WHERE DATEPART( day, DATEADD( Year, 
DATEPART( Year, GETDATE()) - DATEPART( Year, @EmpDOB), @EmpDOB))
= DATEPART( day, GETDATE());


EXEC [MySchemaEMS].EmployeeBirthday '03-01-2017'

DROP PROCEDURE [MySchemaEMS].EmployeeBirthday